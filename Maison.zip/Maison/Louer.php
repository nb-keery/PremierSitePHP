<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" /> 
		<!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
				<link rel="shortcut icon" href="logo.png" type="image/x-icon" /> <!-- Mauvaise indentataion-->
				<title>Immobilier - Louer</title> <!-- Mauvaise indentataion-->
			<link rel="stylesheet" type="text/css" href="immo.css"> <!-- Il est préférable d'appeler son style style.css-->
	</head>


<body>
			
			<header>
				<?php include("nav.php"); ?>
			</header>
			<section>
				<img src="images/projet.jpg" width="980" height="325">

				<h2>Annonces</h2>

				<br><br>

				<?php 	include ("maison.php"); 

					for ($i=0; $i < count($louer) ; $i++) 
					{ 
						
						echo '<li class="annonce"> 
				                  <a href=" ' . $louer[$i]['url'] . ' "target="_blank" ">  
				                    <img src="images/maison.jpg" id="home">
				                    <div id="ads">
					                    <h3>' . $louer[$i]['title'] . ' </h3>  
					                    <p>Surface : ' .  $louer[$i]['square_m']  . ' m² </p> 
					                    <p>Prix : ' . $louer[$i]['price'] .' €</p> <br><br>
					                    <button id="louer">Louer</button>
				                    </div>
				                  </a> 
				              </li>';
				    }
       			?> 
				<br><br><br>
			
			</section>
			<br><br>
				<?php include("footer.php"); ?>
	
	</body>
</html>