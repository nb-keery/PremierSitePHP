<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" /> 
		<!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
				<link rel="shortcut icon" href="logo.png" type="image/x-icon" />
				<title>Immobilier - Contact</title>
			<link rel="stylesheet" type="text/css" href="immo.css">
	</head>


<body>
			
			<header>
						<?php include("nav.php"); ?>
			</header>

			<section>
				<img src="images/projet.jpg" width="980" height="325">

				<h2>Coordonnées</h2>

				<div id="contact">
					<div id="left">
						<h3 id="nom">IMMOBILIER.FR</h3>
						<ul id="info">
							<li>18 rue des chevaliers saint jean</li>
							<li>91100</li>
							<li>Corbeil-Essonnes</li>
							<li>France</li>
							<li>0611909382</li>
						</ul>
					</div>


					<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2638.1479244918737!2d2.4766337999999997!3d48.6070117!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e5e72963605cab%3A0x9c4b0347361d6234!2s18+Rue+des+Chevaliers+Saint-Jean%2C+91100+Corbeil-Essonnes!5e0!3m2!1sfr!2sfr!4v1421933369357"
					 width="300" height="190" frameborder="0" id="map"></iframe>

					<div id="right">
						<FORM method=post action="message.php"> <!-- faut html à ce niveau -->
						<input type"text" placeholder="Nom" required>
						<input type"text" placeholder="Mail" required>
						<input type"text" placeholder="Téléphone">
						<textarea placeholder="Message" required></textarea>
						<button type="submit">Envoyer</button>
					</div>
				</div>
				<br>

			</section>
			
			<br><br>
			
				<?php include("footer.php"); ?>
	
	</body>
</html>