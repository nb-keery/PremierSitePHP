<!-- 
	il faut créer des dossiers 'include, img'
 -->
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" /> 
		<!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
				<link rel="shortcut icon" href="logo.png" type="image/x-icon" />
				<title>Immobilier - Accueil</title>
			<link rel="stylesheet" type="text/css" href="immo.css">
	</head>
		
	
	<body>
			
			<header>
						<?php include ("nav.php"); ?>
			</header>
			<section>
				<img src="images/projet.jpg" width="980" height="325">

				<h2>Présentation</h2>
				<p>
					Cum saepe multa, tum memini domi in hemicyclio sedentem, ut solebat, cum et ego essem una et pauci admodum familiares, in eum sermonem illum incidere qui tum forte multis erat in ore. Meministi enim profecto, Attice, et eo magis, quod. Sulpicio utebare multum, cum is tribunus plebis capitali odio a quiqo. Pompeio, qui tum erat consul, dissideret, quocum coniunctissime et amantissime vixerat, quanta esset hominum vel admiratio vel querella.
					<br><br>
					Quibus ita sceleste patratis Paulus cruore perfusus reversusque ad principis castra multos coopertos paene catenis adduxit in squalorem deiectos atque maestitiam, quorum adventu intendebantur eculei uncosque parabat carnifex et tormenta. et ex is proscripti sunt plures actique in exilium alii, non nullos gladii consumpsere poenales. nec enim quisquam facile meminit sub Constantio, ubi susurro tenus haec movebantur, quemquam absolutum.
					<br><br>
					Eminuit autem inter humilia supergressa iam impotentia fines mediocrium delictorum nefanda Clematii cuiusdam Alexandrini nobilis mors repentina; cuius socrus cum misceri sibi generum, flagrans eius amore, non impetraret, ut ferebatur, per palatii pseudothyrum introducta, oblato pretioso reginae monili id adsecuta est, ut ad Honoratum tum comitem orientis formula missa letali omnino scelere nullo contactus idem Clematius nec hiscere nec loqui permissus occideretur.
				</p>
					<br>
			</section>
			
			<br><br> <!-- L'utilisation du css est préférable-->
			<?php include("footer.php"); ?>
	
	</body>
</html>