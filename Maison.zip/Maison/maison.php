

<?php

$ads = array(

  array('url' => 'http://www.seloger.com/annonces/achat/appartement/saint-denis-93/republique-gare-porte-de-paris/74398691.htm','title' => 'Appartement 4 pièces 84 m² ','square_m' => '84','price' => '199700'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-19eme-75/manin-jaures/74403495.htm','title' => 'Appartement 3 pièces 58 m² ','square_m' => '58','price' => '365000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-18eme-75/74430039.htm','title' => 'Appartement 5 pièces 90 m² ','square_m' => '90','price' => '319500'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/saint-denis-93/republique-gare-porte-de-paris/74450751.htm','title' => 'Appartement 3 pièces 55 m² ','square_m' => '55','price' => '820'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-18eme-75/montmartre/74473227.htm','title' => 'Appartement 3 pièces 47 m² ','square_m' => '47','price' => '420000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-18eme-75/amiraux-simplon-poissonniers/74478899.htm','title' => 'Appartement 3 pièces 54 m² ','square_m' => '54','price' => '410000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-18eme-75/clignancourt-jules-joffrin/74492373.htm','title' => 'Studio 28,39 m² ','square_m' => '28','price' => '980'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-18eme-75/clignancourt-jules-joffrin/74497259.htm','title' => 'Appartement 3 pièces 46 m² ','square_m' => '46','price' => '390000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-18eme-75/montmartre/74506819.htm','title' => 'Appartement 3 pièces 54 m² ','square_m' => '54','price' => '424000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/saint-denis-93/centre-ville-basilique/74514433.htm','title' => 'Appartement 3 pièces 57 m² ','square_m' => '57','price' => '148000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-15eme-75/vaugirard-parc-des-expositions/74519177.htm','title' => 'Appartement 2 pièces 44 m² ','square_m' => '44','price' => '310000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-10eme-75/74519251.htm','title' => 'Vente Appartement 3 pièces','square_m' => '64','price' => '450000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-19eme-75/74564429.htm','title' => 'Appartement 2 pièces 42 m² ','square_m' => '42','price' => '200000'),
  array('url' => 'http://www.seloger.com/annonces/locations/appartement/paris-18eme-75/clignancourt-jules-joffrin/74570393.htm','title' => 'Studio 25 m² ','square_m' => '25','price' => '830'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-19eme-75/manin-jaures/74577203.htm','title' => 'Appartement 3 pièces 68 m² ','square_m' => '68','price' => '440000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-18eme-75/goutte-d-or-chateau-rouge/74593255.htm','title' => 'Appartement 3 pièces','square_m' => '60','price' => '395980'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-18eme-75/montmartre/74602087.htm','title' => 'Appartement 3 pièces 47 m² ','square_m' => '47','price' => '412000'),
  array('url' => 'http://www.seloger.com/annonces/investissement/appartement/saint-denis-93/la-plaine-stade-de-france/74603669.htm','title' => 'Studio 16,4 m² ','square_m' => '16','price' => '58000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-10eme-75/74619451.htm','title' => 'Appartement 3 pièces 55 m² ','square_m' => '55','price' => '419000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-19eme-75/secretan/74623373.htm','title' => 'Appartement 4 pièces 62 m² ','square_m' => '62','price' => '380000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-18eme-75/clignancourt-jules-joffrin/74623503.htm','title' => 'Appartement 3 pièces 66 m² ','square_m' => '66','price' => '420000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-19eme-75/flandre-aubervilliers/74643239.htm','title' => 'Appartement 4 pièces 65 m² ','square_m' => '65','price' => '232000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-10eme-75/faubourg-du-temple-hopital-saint-louis/74647169.htm','title' => 'Appartement 3 pièces 47 m² ','square_m' => '47','price' => '330000'),
  array('url' => 'http://www.seloger.com/annonces/locations/appartement/saint-denis-93/la-plaine-stade-de-france/74663289.htm','title' => 'Appartement 3 pièces 64 m² ','square_m' => '64','price' => '980'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-3eme-75/archives/74667295.htm','title' => 'Appartement 2 pièces 34 m² ','square_m' => '34','price' => '368000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-19eme-75/buttes-chaumont/74674941.htm','title' => 'Appartement 3 pièces 50 m² ','square_m' => '50','price' => '395000'),
  array('url' => 'http://www.seloger.com/annonces/locations/appartement/paris-18eme-75/la-chapelle-marx-dormoy/74685335.htm','title' => 'Studio 26 m² ','square_m' => '26','price' => '658'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-10eme-75/chateau-d-eau-lancry/74686569.htm','title' => 'Appartement 3 pièces 52 m² ','square_m' => '52','price' => '440000'),
  array('url' => 'http://www.seloger.com/annonces/locations/appartement/paris-18eme-75/clignancourt-jules-joffrin/74689747.htm','title' => 'Studio 25,73 m² ','square_m' => '26','price' => '677'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-19eme-75/flandre-aubervilliers/74692997.htm','title' => 'Appartement 3 pièces 50 m² ','square_m' => '50','price' => '185000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/saint-denis-93/republique-gare-porte-de-paris/74719793.htm','title' => 'Appartement 2 pièces 42 m² ','square_m' => '42','price' => '195000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-10eme-75/74719943.htm','title' => 'Appartement 3 pièces 51 m² ','square_m' => '51','price' => '407000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-18eme-75/amiraux-simplon-poissonniers/74728061.htm','title' => 'Appartement 3 pièces 56 m² ','square_m' => '56','price' => '445000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/saint-denis-93/republique-gare-porte-de-paris/74732775.htm','title' => 'Appartement 2 pièces 54 m² ','square_m' => '54','price' => '184500'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/paris-18eme-75/montmartre/74736067.htm','title' => 'Duplex 3 pièces 50 m² ','square_m' => '50','price' => '409000'),
  array('url' => 'http://www.seloger.com/annonces/achat/appartement/saint-denis-93/republique-gare-porte-de-paris/74748305.htm','title' => 'Studio de 22 m² ','square_m' => '22','price' => '80000'),
  array('url' => 'http://www.seloger.com/annonces/locations/appartement/paris-18eme-75/clignancourt-jules-joffrin/74777173.htm','title' => 'Studio de 25 m² ','square_m' => '25','price' => '790')
  );

$louer = array(



  );


$acheter = array(



  );

  for ($i=0; $i < count($ads); $i++)
    {
      
      if ($ads[$i]['price'] < 1000) {

        array_push($louer, $ads[$i]);
         }

        
      else { 

         array_push($acheter, $ads[$i]);

          }
    }

?>