<!-- La création de cette page n'est pas dispensable, la supprimer. Faire mettre le message dans la page contact -->
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" /> 
		<!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
				<link rel="shortcut icon" href="logo.png" type="image/x-icon" />
				<title>Immobilier - Accueil</title>
			<link rel="stylesheet" type="text/css" href="immo.css">
	</head>
		
	
	<body>
			
			<header>
					<?php include("nav.php"); ?>
			</header>

			<section>
				<p id="message">Votre message a bien été envoyé, merci.</p>
			</section>
			
			<br><br>
			<?php include("footer.php"); ?>
	
	</body>
</html>