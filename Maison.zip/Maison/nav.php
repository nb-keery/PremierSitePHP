				<div id="tete">
					<img src="images/logo2.png" width="95" height="95" id="logo">
					<img src="images/titre.png" id="titre">
				</div>

				<nav>
					<ul>
						<li class="<?php 
																 	$url = $_SERVER['REQUEST_URI'];
															        $page = explode("/", $url);
															        $nav = end($page);

															        if ($nav == 'index.php') {
															        	echo "actif";
															        }

															        else {
															        	echo " "; } ?>"><a href="index.php">Accueil</a></li>
						<li class="<?php 
																 	$url = $_SERVER['REQUEST_URI'];
															        $page = explode("/", $url);
															        $nav = end($page);

															        if ($nav == 'annonces.php') {
															        	echo "actif";
															        }

															        else {
															        	echo " "; } ?>"><a href="annonces.php">Acheter</a></li>
						<li class="<?php 
																 	$url = $_SERVER['REQUEST_URI'];
															        $page = explode("/", $url);
															        $nav = end($page);

															        if ($nav == 'louer.php') {
															        	echo "actif";
															        }

															        else {
															        	echo " "; } ?>"><a href="louer.php">Louer</a></li>
						<li class="<?php 
																 	$url = $_SERVER['REQUEST_URI'];
															        $page = explode("/", $url);
															        $nav = end($page);

															        if ($nav == 'contact.php') {
															        	echo "actif";
															        }

															        else {
															        	echo " "; } ?>"><a href="contact.php">Contact</a></li>
					</ul>
				</nav>